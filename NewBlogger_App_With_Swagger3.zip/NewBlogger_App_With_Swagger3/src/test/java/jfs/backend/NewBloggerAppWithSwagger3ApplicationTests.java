package jfs.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewBloggerAppWithSwagger3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
